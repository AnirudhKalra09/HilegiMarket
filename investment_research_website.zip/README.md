# Hilegi Research Website
This repository contains the files for a simple investment research company website. 

## How to Deploy
1. **Hosting Options**:
   - Use free hosting platforms like [Netlify](https://www.netlify.com/) or [GitHub Pages](https://pages.github.com/).
   - For advanced hosting, use AWS, DigitalOcean, or Google Cloud.

2. **Steps**:
   - Upload all files to your hosting platform.
   - Ensure `index.html` is in the root directory.
   - Test the website for mobile and desktop responsiveness.

3. **Customizations**:
   - Replace `hero-bg.jpg` with your own background image.
   - Edit `styles.css` to change colors or typography.
   - Use `script.js` to add interactivity.

## License
Free to use and modify for personal or business purposes.
